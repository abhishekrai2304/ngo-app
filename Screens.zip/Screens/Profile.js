import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View, Dimensions, TextInput, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import Animated from 'react-native-reanimated';
import firebase from 'firebase';
import {Drawer} from 'react-native-paper';
console.ignoredYellowBox = [
    'Setting a timer'
  ]

const {width,height}=Dimensions.get('window');

var firebaseConfig = {
    apiKey: "AIzaSyBkpt6HFwXiU09qrc7Jk1BvWLGsDx5U9j4",
    authDomain: "login2-6d807.firebaseapp.com",
    databaseURL: "https://login2-6d807.firebaseio.com",
    projectId: "login2-6d807",
    storageBucket: "login2-6d807.appspot.com",
    messagingSenderId: "803075299968",
    appId: "1:803075299968:web:7abd54fb0b5a88d3e92465",
    measurementId: "G-VPMHGQ9VLC"
  };
if(!(firebase.apps.length)){
firebase.initializeApp(config);}

const Profile = ({navigation, route}) => {
  let [selectedImage, setSelectedImage] = React.useState(null);
  const {Email} = route.params;
  const {Username} = route.params;
  const {Uri} = route.params;
  const [Pass, setPass] = React.useState(false);
  const [EMail, setMail] = React.useState(false);
  const [password, setpass] = React.useState('');
  const [Cpassword, setcpass] = React.useState('');
  const [email, setemail] = React.useState('');
  const [MAIL, SETMAIL] = React.useState(Email);

    const emailhandler = (em) => {
        setemail(em);
    }
    const submitMail = () => {
        if(email === "") {
            alert("Enter Username!",  [{ text: 'Ok', style: 'cancel'}])
        } else {
          firebase.database().ref(Username).update({
            Email: email
          }).then(() => {
            SETMAIL(email);
            alert("Email Updated Successfully!")
            setMail(false);
          })
        }
    }

    const changeMailHandler = () => {
      setMail(true);
    }

  let openImagePickerAsync = async () => {
    let permissionResult = await ImagePicker.requestCameraRollPermissionsAsync();
    if (permissionResult.granted === false) {
      alert('Permission to access camera roll is required!');
      return;
    }

    let pickerResult = await ImagePicker.launchImageLibraryAsync();
    if (pickerResult.cancelled === true) {
      return;
    }
    setSelectedImage({ localUri: pickerResult.uri });

    const response = await fetch(pickerResult.uri);
    const blob = await response.blob()
    var ref = firebase.storage().ref().child(Username)
    return ref.put(blob);
  };

  const passHandler= () => {
    setPass(true);
  }

const passhandler = (pass) => {
    setpass(pass);
};
const cpasshandler = (cpass) => {
    setcpass(cpass);
};
const submit = () => {
    if(password === "" || Cpassword === "") {
       alert("Warning! Password or Confirm Password is missing!",  [{ text: 'Ok', style: 'cancel'}]);
    }else if(password === Cpassword) {      
          firebase.database().ref(Username).update({
            Password: password
          }).then(() => {
            alert("Password Updated Successfully!")
            setPass(false);
          })
    }
     else {
       alert("Password And Confirm Password should be same!");
    }
};

const onCancelHandler = () => {
  setPass(false);
  setMail(false);
}

  if(EMail) {
    return(
      <View style={{marginTop: 80}}>
      <View style={styles.section1}>
                  <Image source= {require('../assets/email.png')} style={styles.ImageStyle} />
                  <TextInput
                      placeholder="EMAIL"
                      style={{...styles.textInput, fontSize: 15}}
                      placeholderTextColor="black"
                      underlineColorAndroid="transparent"
                      onChangeText = {emailhandler}
                  />
      </View>
      <TouchableOpacity  onPress = {submitMail} activeOpacity = {0.9}>
              <Animated.View style={{
                  ...styles.button, 
                  backgroundColor: '#0000ff', 
                  marginTop: 10, 
                  justifyContent: "center",                     
              }}>
              
              <Text style= {{fontSize: 20, fontWeight: "bold", color: 'white'}}> 
                 SUBMIT
              </Text>
              </Animated.View>
      </TouchableOpacity>

      <TouchableOpacity onPress = {onCancelHandler}>
          <Animated.View style={{  
                  marginTop: 10, 
                  justifyContent: "center",
                  alignItems: "center"                     
              }}>
          <Text style= {{fontSize: 20, fontWeight: "bold", color: 'red'}}> 
                  CANCEL
          </Text>
          </Animated.View>
      </TouchableOpacity>

  </View>
    );
  }

  if (selectedImage !== null) {
    return (
      <View style={styles.container}>
      <Drawer.Section style = {styles.drawerSection}>
      <Image source={{ uri: selectedImage.localUri }} style={styles.thumbnail} />
        <TouchableOpacity onPress={openImagePickerAsync} style={{marginLeft:150, bottom: 50}}>
        <Image source = {require("../assets/plus.png")} style ={{borderRadius: 100}}/>
      </TouchableOpacity> 
      </Drawer.Section>
      <Drawer.Section style = {styles.drawerSection}>
      <View style = {styles.oct}>
      <View style={{...styles.section, marginBottom: -400,marginLeft: -180}}>
        <Image source = {require('../assets/name.png')}  
        style = {styles.ImageStyle} />
        <View style = {{flexDirection: 'column'}}>
        <Text style = {{color: 'gray'}}>Name:</Text>
        <Text style={{fontSize: 15, marginLeft: 10}}>{Username}</Text>
        </View>
        
    </View>
    <View style={{...styles.section}}>
        <Image source = {require('../assets/email.png')}  
        style = {styles.ImageStyle} />
        <View style = {{flexDirection: 'column'}}>
        <Text style = {{color: 'gray'}}>Email:</Text>
        <Text style={{fontSize: 15, marginLeft: 10}}>{MAIL}</Text>
        </View>
        
        <View style = {{left: 30}}>
        <TouchableOpacity onPress = {changeMailHandler}>
          <Image source = {require('../assets/edit.png')}  
            style = {{...styles.ImageStyle}} />
        </TouchableOpacity>
        </View>
    </View>
    </View>
    </Drawer.Section>
    <Drawer.Section style = {{...styles.drawerSection, marginTop: -300}}>
    <TouchableOpacity onPress = {passHandler}>
    <View> 
          <Text style={{color: "blue", fontSize: 18}}>Change Password</Text>
      </View>
      </TouchableOpacity>
      </Drawer.Section>
    </View>
      
    );
  }

  if(Pass) {
    return (
      <View style={{marginTop: 80}}>
      <View style={styles.section1}>
                  <Image source= {require('../assets/pass.png')} style={styles.ImageStyle} />
                  <TextInput
                      placeholder="PASSWORD"
                      style={{...styles.textInput, fontSize: 15}}
                      placeholderTextColor="black"
                      underlineColorAndroid="transparent"
                      onChangeText = {passhandler}
                      secureTextEntry = {true}
                  />
      </View>
      <View style={styles.section1}>
                  <Image source= {require('../assets/pass.png')} style={styles.ImageStyle} />
                  <TextInput
                      placeholder="CONFIRM PASSWORD"
                      style={{...styles.textInput, fontSize: 15}}
                      placeholderTextColor="black"
                      underlineColorAndroid="transparent"
                      onChangeText = {cpasshandler}
                      secureTextEntry = {true}
                  />
      </View>
      <TouchableOpacity  onPress = {submit} activeOpacity = {0.9}>
              <Animated.View style={{
                  ...styles.button, 
                  backgroundColor: '#0000ff', 
                  marginTop: 10, 
                  justifyContent: "center",                     
              }}>
              
              <Text style= {{fontSize: 20, fontWeight: "bold", color: 'white'}}> 
                 SUBMIT
              </Text>
              </Animated.View>
      </TouchableOpacity>

      <TouchableOpacity onPress = {onCancelHandler}>
          <Animated.View style={{  
                  marginTop: 10, 
                  justifyContent: "center",
                  alignItems: "center"                     
              }}>
          <Text style= {{fontSize: 20, fontWeight: "bold", color: 'red'}}> 
                  CANCEL
          </Text>
          </Animated.View>
      </TouchableOpacity>

  </View>
    );
  }
 

  return (
    
    <View style={styles.container}>
      <Drawer.Section style = {styles.drawerSection}>
      <Image source={{uri: Uri}} style={styles.thumbnail} />
        <TouchableOpacity onPress={openImagePickerAsync} style={{marginLeft:150, bottom: 40}}>
        <Image source = {require("../assets/plus.png")} style ={{borderRadius: 100}}/>
      </TouchableOpacity>
      </Drawer.Section>
      <Drawer.Section style = {styles.drawerSection}>
      <View style = {styles.oct}>
      <View style={{...styles.section, marginBottom: -400, marginLeft: -180}}>
        <Image source = {require('../assets/name.png')}  
        style = {styles.ImageStyle} />
        <View style = {{flexDirection: 'column'}}>
        <Text style = {{color: 'gray'}}>Name:</Text>
        <Text style={{fontSize: 15, marginLeft: 10}}>{Username}</Text>
        </View>        
    </View>
    <View style={{...styles.section}}>
        <Image source = {require('../assets/email.png')}  
        style = {styles.ImageStyle} />
        <View style = {{flexDirection: 'column'}}>
        <Text style = {{color: 'gray'}}>Email:</Text>
        <Text style={{fontSize: 15, marginLeft: 10}}>{MAIL}</Text>
        </View>
        
        <View style = {{ left: 30}}>
        <TouchableOpacity onPress = {changeMailHandler} activeOpacity = {0.1}>
        <Image source = {require('../assets/edit.png')}  
        style = {{...styles.ImageStyle}} />
        </TouchableOpacity>
        </View>
    </View>
    </View>
    </Drawer.Section>
    <Drawer.Section style = {{...styles.drawerSection, marginTop: -300}}>
    <TouchableOpacity onPress = {passHandler}>
    <View> 
          <Text style={{color: "blue", fontSize: 18}}>Change Password</Text>
      </View>
      </TouchableOpacity>
      </Drawer.Section>
    </View>
  );
}

export default Profile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100
  },
  oct: {
      flex: 1,
      justifyContent:"center",
      alignItems: "center",
      height: 100
  },
  ImageStyle:{
    padding: 10,
    margin: 10,
    resizeMode : 'stretch',
    alignItems: 'center'
},
  thumbnail: {
    width: 250,
    height: 250,
    resizeMode: 'cover',
    borderRadius: 450,
  },
  drawerSection: {
    marginTop: -100,
  },
  section: { 
    flex: 1,
    flexDirection: "row",
    justifyContent: 'center',
    alignItems: 'center', 
    borderRadius: 30 ,
    marginLeft: -50,
    top: -130
},
textInput:{
  flex: 1,
},  
section1: { 
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#fff',
  borderWidth: .5,
  borderColor: '#000',
  height: 80,
  borderRadius: 50 ,
  borderWidth:1,
  margin: 10
},
button: {
  backgroundColor: 'white',
  height: 70,
  marginHorizontal: 20,
  borderRadius: 35,
  alignItems: "center",
  justifyContent: "center",
  marginVertical: 5,
  shadowOffset: {width: 2,height: 2},
  shadowColor: 'black',
  shadowOpacity: 0.2,
  elevation: 8
},
});
