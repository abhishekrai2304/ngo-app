import React from 'react';
import { View, Button, StyleSheet, Image } from 'react-native';
import { Container, Header, Content, Card, CardItem, Body, Text, Left, Thumbnail } from 'native-base';
import Colors from '../Constants/Colors';
const Bookmarks = () => {
  return (
    // <View style={styles.container}>
    //   <Text>Bookmark Screen</Text>
    //   <Button
    //     title="Click Here"
    //     onPress={() => alert('Button Clicked!')}
    //   />
    // </View>
    <Container>
      {/* <Header style = {{backgroundColor:'white'}} /> */}
      <Header header = "My" style={{  backgroundColor:Colors.niceGreen }} >
        {/* <Text style = {{textAlign:'center'}}>Trust</Text> */}
        </Header>
      <Content style={{ margin: 10, backgroundColor:'white' }}>

        <Card >
          <CardItem>
            <Left>
              <Thumbnail source={{uri : 'https://api.adorable.io/avatars/50/abott@adorable.png'}} />
              <Body>
                <Text style={{ fontWeight: 'bold' }} >Abhishek Rai </Text>
              </Body>
            </Left>
          </CardItem>
          {/* <CardItem>
            <Body>
              <Text>
              //Your text here
              </Text>
            </Body>
          </CardItem> */}
          <CardItem cardBody>
              <Image source={require('../assets/mypic.jpg')} style={{height: 200, width: null, flex: 1}}/>
            </CardItem>
          {/* <CardItem footer>
            <Text>GeekyAnts</Text>
          </CardItem> */}
        </Card>

        <Card>
        <CardItem>
            <Left>
              <Thumbnail source={{uri : 'https://api.adorable.io/avatars/50/abott@adorable.png'}} />
              <Body>
                <Text style={{ fontWeight: 'bold' }} >Rai Trust </Text>
              </Body>
            </Left>
          </CardItem>
          <CardItem>
            <Text> Government Polytechnic Mumbai is an autonomous institute of Government of Maharashtra. Recently in 2010, we have celebrated Golden Jubilee of the institute.{'\n\n'}We have a team of highly qualified, experienced and dedicated faculties and non-teaching staff who are devoted to achieve excellence in the every activity of the institute. We own an excellent infrastructure, well equipped engineering departments, libraries, training and Placement cell, class rooms, seminar rooms and Auditorium Hall etc. {'\n\n'}The synergic efforts taken at the institute will help to achieve the vision of the institute and  make our student globally competitive entrepreneurs and employable engineers. This will ultimately help to transform them into a knowledge pool for India.</Text>

          </CardItem>
        </Card>
        <Card>
        <CardItem>
            <Left>
              <Thumbnail source={{uri : 'https://api.adorable.io/avatars/50/abott@adorable.png'}} />
              <Body>
                <Text style={{ fontWeight: 'bold' }} >Abhishek Rai </Text>
              </Body>
            </Left>
          </CardItem>
          <CardItem>
            <Text>Er.Abhishek V. Rai{'\n\n'} Ph:  8169381150{'\n\n'}  Email:  abhishekrai2304@gmail.com</Text>
          </CardItem>
        </Card>
      </Content>
    </Container>
  );
};

export default Bookmarks;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
});