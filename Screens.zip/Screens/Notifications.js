import React from 'react';
import {View, Text, StyleSheet, Button} from 'react-native';
import Home from '../Screens/Home';
import Main from '../Components/Main';
import Chat from '../Components/Chat';
import Profil from '../Screens/Profile';
import { createStackNavigator } from 'react-navigation-stack'
import {createAppContainer} from 'react-navigation';


const Notifications = ({navigation})=>{
  // const navigator = createStackNavigator({
  //   Main: { screen: Main },
  //   Chat: { screen: Chat },
  // });
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Notifications Screen</Text>
      <Button title = "Go to Home Screen" onPress={()=>navigation.navigate('Home')}/>
    </View>
      );
};
const styles = StyleSheet.create({

});

// const ChatApp = createAppContainer(navigator);
export default Notifications;