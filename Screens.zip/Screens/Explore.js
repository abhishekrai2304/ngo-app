import React from 'react';
import {View, Text, Button, StyleSheet} from 'react-native';
const Explore = ()=>{
    return(
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text>Explore Screen</Text>
            </View>
    );
};
const styles = StyleSheet.create({

});
export default Explore;