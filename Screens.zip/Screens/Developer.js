import React from 'react';
import { View, Image } from 'react-native';
import { Container, Header, Content, Card, CardItem, Body, Text, Left, Thumbnail } from 'native-base';
import Colors from '../Constants/Colors';
const Developers = () => {
    return (
        <Container >
            <Header style = {{backgroundColor:'white'}}>
                <Text style = {{margin: 15}}>Our Developers</Text>
            </Header>
            <Content style={{ margin: 10, backgroundColor: 'white' }}>
                <Card >

                    <Card >
                        <CardItem>
                            <Left>
                                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                                <Body>
                                    <Text style={{ fontWeight: 'bold' }} >Abhishek Rai </Text>
                                </Body>
                            </Left>
                        </CardItem>
                        <CardItem>
                            <Image source={require('../assets/mypic.jpg')} style={{ height: 200, width: null, flex: 1 }} />
                        </CardItem>
                    </Card>

                    <Card>
                    <CardItem>
                            <Left>
                                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                                <Body>
                                    <Text style={{ fontWeight: 'bold' }} >Harsha Rathi </Text>
                                </Body>
                            </Left>
                        </CardItem>
                        <CardItem>
                            <Image source={require('../assets/harsha.jpg')} style={{ height: 200, width: null, flex: 1 }} />
                        </CardItem>
                    </Card>

                    <Card>
                    <CardItem>
                            <Left>
                                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                                <Body>
                                    <Text style={{ fontWeight: 'bold' }} >Divya Kharode </Text>
                                </Body>
                            </Left>
                        </CardItem>
                        <CardItem>
                            <Image source={require('../assets/divya.jpg')} style={{ height: 200, width: null, flex: 1 }} />
                        </CardItem>
                    </Card>


                </Card>
            </Content>
        </Container>
    );
};
export default Developers;