import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, ScrollView, Image, ImageBackground, FlatList } from 'react-native';
import { Container, Header, Content, Card, CardItem, Body, Left, Thumbnail } from 'native-base';
import Colors from '../Constants/Colors';
import Cards from '../Components/Card';
import Notifications from '../Screens/Notifications';
import { TouchableOpacity, PanGestureHandler } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import firebase from 'firebase';
import { setLightEstimationEnabled } from 'expo/build/AR';
var firebaseConfig = {
  apiKey: "AIzaSyBkpt6HFwXiU09qrc7Jk1BvWLGsDx5U9j4",
  authDomain: "login2-6d807.firebaseapp.com",
  databaseURL: "https://login2-6d807.firebaseio.com",
  projectId: "login2-6d807",
  storageBucket: "login2-6d807.appspot.com",
  messagingSenderId: "803075299968",
  appId: "1:803075299968:web:7abd54fb0b5a88d3e92465",
  measurementId: "G-VPMHGQ9VLC"
};
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig)
}
const Home = ({ route, navigation }) => {
  const [Names, setnames] = useState([]);
  const [ngoname, setngoname] = useState('');
  const [once, setonce] = useState(true);
  const [on, seton] = useState(true);
  const [visible, setvisible] = useState(true)
  const [email, setemail] = useState('')
  const [name, setname] = useState('')
  const [contact, setcontact] = useState('')
  const [des, setdes] = useState('')
  const [start, setstart] = useState(false)
  const [cit, setcit] = useState('')
  let img;
  let img1;
  let city = ""

  for (let i in route.params) {
    city += route.params[i]
  }

  if (city === "" && on) {

    const listItems = ["Akola", "Amravati", "Aurangabad", "Ahmednagar", "Beed", "Bhusaval", "Chandrapur", "Dhule", "Gondia", "Hinganghat",
      "Ichalkaranji", "Jalgaon", "Kolhapur", "Latur", "Malegaon", "Nagpur", "Nashik", "Nandurbar","Mumbai", "Miraj", "Osmanabad", "Pune", 
      "Panvel", "Solapur", "Sangli", "Satara", "Thane", "Udgir", "Wardha", "Yavatmal"];

    for (listcity in listItems) {
      let cities = listItems[listcity];
      firebase.database().ref('NGO/' + cities).once('value', (data) => {
        const ab = data.exportVal()
        for (const key in ab) {
          if (ab.hasOwnProperty(key)) {
            setnames(currentngo => [...currentngo, { id: cities, value: key }]);
          }
        }
      })
    }
    seton(false);
  }
  else if (city && once) {
    setnames([])
    firebase.database().ref('NGO/' + city).once('value', (data) => {
      const ab = data.exportVal()
      for (const key in ab) {
        if (ab.hasOwnProperty(key)) {
            setnames(currentngo => [...currentngo, { id: city, value: key }]);
        }
      }
    })
    setonce(false)
    setstart(true);
  }

  const Pagehandler = (item, itemid) => {
    console.log(item, itemid)
    setngoname(item);
    firebase.database().ref('NGO/' + itemid + '/' + item).once('value', (data) => {
      setvisible(false);
      setcontact(data.val().Contact)
      setname(data.val().Name)
      setdes(data.val().Description)
      setcit(data.val().City)
      setemail(data.val().Email)
    })
    setvisible(false)
  }

  const visibilityhandler = () => {
    setvisible(true)
  }
 
  if (visible && !(start)) {
    return (
      <ScrollView>
        <View style={styles.screen}>
          <View style={{ backgroundColor: '' }}>
          </View>
          <View>
            <FlatList
              data={Names}
              renderItem={({ item }) =>
                <TouchableOpacity onPress={Pagehandler.bind(this, item.value, item.id)} style={styles.inputContainer}>
                  <Cards >
                    <Text>{item.value}</Text>
                  </Cards>
                </TouchableOpacity>}
            />
          </View>
        </View>
      </ScrollView>
    );
  }
  else  if (visible  && Names.length>0) {
    return (
      <ScrollView>
        <View style={styles.screen}>
          <View style={{ backgroundColor: '' }}>
          </View>
          <View>
            <FlatList
              data={Names}
              renderItem={({ item }) =>
                <TouchableOpacity onPress={Pagehandler.bind(this, item.value, item.id)} style={styles.inputContainer}>
                  <Cards >
                    <Text>{item.value}</Text>
                  </Cards>
                </TouchableOpacity>}
            />
          </View>
        </View>
      </ScrollView>
    );
  }
  else if (visible && (Names.length == 0) && start) {
    return (
      <View style={{ alignItems: 'center', flex: 1, paddingTop: 250 }}>
        <Cards style={{ backgroundColor: Colors.niceGreen, width: 250 }}>
          <Text style={{ color: 'white', textAlign: 'center', fontSize: 17 }}>Sorry No NGO Found in the Choosen City</Text>
        </Cards>
      </View>
    );
  }
  else if (!visible) {
    return (
      <Container>
        <Content style={{ margin: 10, backgroundColor: 'white' }}>
          <Card >
            <CardItem>
              <Left>
                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                <Body>
                  <Text style={{ fontWeight: 'bold' }} >{name} </Text>
                </Body>
              </Left>
            </CardItem>
            <CardItem cardBody>
              <Image source={require("./Aashapura.jpg")} style={{ height: 150, flex: 1 }} />
            </CardItem>
          </Card>
          <Card>
            <CardItem>
              <Left>
                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                <Body>
                  <Text style={{ fontWeight: 'bold' }} >{name} </Text>
                </Body>
              </Left>
            </CardItem>
            <CardItem>
              <Text> {des} </Text>
            </CardItem>
          </Card>
          <Card>
            <CardItem>
              <Left>
                <Thumbnail source={{ uri: 'https://api.adorable.io/avatars/50/abott@adorable.png' }} />
                <Body>
                  <Text style={{ fontWeight: 'bold' }} >{name} </Text>
                </Body>
              </Left>
            </CardItem>
            <CardItem>
              <Text>Ph:  {contact}{'\n\n'}Email/Website:  {email} {'\n\n'} City: {cit}</Text>
            </CardItem>
          </Card>
          <View style={styles.backcontainer}>
            <Button onPress={visibilityhandler} title="Back" />
          </View>
        </Content>
      </Container>

     );
  }

};
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 70,
    alignItems: 'center',
  },
  inputContainer: {
    width: 'auto',
    maxWidth: '120%',
    alignItems: 'center',
    height: 'auto',
    margin: 15,
  },
  cardContainer: {
    flexDirection: 'row',
  },
  imgContainer: {
    width: '120%',
    height: 200,
    maxWidth: '120%',
    padding: 10,
  },
  image: {

    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    borderRadius: 10,
    width: 900,
    maxWidth: '95%',
    height: 200,
  },
  buttonContainer: {
    flexDirection: 'row',
    flex: 1,
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 15,
  },
  backcontainer: {
    paddingBottom: 10, paddingTop: 10, width: '100%', alignItems: 'center'
  }
});
export default Home;